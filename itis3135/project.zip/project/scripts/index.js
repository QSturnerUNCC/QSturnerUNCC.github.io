$(document).ready(function () {
    $("#slider").bxSlider({
        auto: true,
        pause: 4000,
        mode: "horizontal",
        preloadImages: "all",
        slideWidth: 700
    });
});